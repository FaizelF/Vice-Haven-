import { FormEvent, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, ArrowRight, Gamepad2, Menu, Play, Volume2, X } from "lucide-react";
import Game from "./game/Game";

const trailerVideoId = "PSyYsyY-bFM";
const trailerEmbedUrl = `https://www.youtube.com/embed/${trailerVideoId}?autoplay=1&rel=0&modestbranding=1`;

// Formspree endpoint — receives email signups (view submissions in your Formspree dashboard)
const formspreeEndpoint = "https://formspree.io/f/xeaqqvae";

// ─────────────────────────────────────────────────────────────
//  EDIT THESE BEFORE PUBLISHING — only you know this info
// ─────────────────────────────────────────────────────────────
const release = {
  status: "In development",        // e.g. "Available now", "In development"
  window: "Coming soon",           // e.g. "Coming 2027"
  platform: "PC · Consoles",       // e.g. "PC · PlayStation · Xbox"
  studio: "F. FRANCIS",    // your studio / creator name
  contact: "you@yourstudio.com",   // your contact email
  youtube: "https://youtube.com/@faizelfrancis-ex5up",
};
// ─────────────────────────────────────────────────────────────

const districts = [
  {
    number: "01",
    name: "Mirage Beach",
    copy: "Sunlit towers, after-hours deals, and a boardwalk that never really sleeps.",
  },
  {
    number: "02",
    name: "The Glades",
    copy: "Mangrove backroads where airboats run fast and old debts run deeper.",
  },
  {
    number: "03",
    name: "Port Sable",
    copy: "Container yards, storm drains, and the beating industrial heart of the county.",
  },
];

const reveal = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0 },
};

function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className={compact ? "wordmark wordmark--compact" : "wordmark"} aria-label="Vice Haven">
      <span className="wordmark__vice">VICE</span>
      <span className="wordmark__haven">HAVEN</span>
    </span>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [trailerOpen, setTrailerOpen] = useState(false);
  const [signedUp, setSignedUp] = useState(false);
  const [sending, setSending] = useState(false);
  const [formError, setFormError] = useState(false);
  const [gameOpen, setGameOpen] = useState(false);

  useEffect(() => {
    if (!trailerOpen && !menuOpen && !gameOpen) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setTrailerOpen(false);
        setMenuOpen(false);
        setGameOpen(false);
      }
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);

    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [menuOpen, trailerOpen, gameOpen]);

  const closeMenu = () => setMenuOpen(false);

  const handleSignup = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    setSending(true);
    setFormError(false);

    try {
      const response = await fetch(formspreeEndpoint, {
        method: "POST",
        body: new FormData(form),
        headers: { Accept: "application/json" },
      });

      if (response.ok) {
        setSignedUp(true);
      } else {
        setFormError(true);
      }
    } catch {
      setFormError(true);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="site-shell">
      <header className="site-header">
        <a href="#top" className="header-logo" aria-label="Vice Haven home">
          <Wordmark compact />
        </a>

        <nav className="desktop-nav" aria-label="Primary navigation">
          <a href="#story">Story</a>
          <a href="#world">World</a>
          <a href="#features">Features</a>
        </nav>

        <button className="header-cta" onClick={() => setTrailerOpen(true)}>
          <Play size={14} fill="currentColor" />
          Watch trailer
        </button>

        <button
          className="menu-button"
          onClick={() => setMenuOpen(true)}
          aria-label="Open menu"
          aria-expanded={menuOpen}
        >
          <Menu size={24} />
        </button>
      </header>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="mobile-menu"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <button onClick={closeMenu} aria-label="Close menu">
              <X size={28} />
            </button>
            <Wordmark compact />
            <nav aria-label="Mobile navigation">
              <a href="#story" onClick={closeMenu}>Story</a>
              <a href="#world" onClick={closeMenu}>World</a>
              <a href="#features" onClick={closeMenu}>Features</a>
            </nav>
            <button
              className="button button--hot"
              onClick={() => {
                closeMenu();
                setTrailerOpen(true);
              }}
            >
              <Play size={17} fill="currentColor" /> Play trailer
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <main>
        <section className="hero" id="top">
          <motion.div
            className="hero__image"
            initial={{ scale: 1.08 }}
            animate={{ scale: 1 }}
            transition={{ duration: 2.2, ease: [0.22, 1, 0.36, 1] }}
          />
          <div className="hero__wash" />
          <motion.div
            className="hero__content"
            initial="hidden"
            animate="visible"
            transition={{ staggerChildren: 0.12, delayChildren: 0.25 }}
          >
            <motion.div variants={reveal}>
              <Wordmark />
            </motion.div>
            <motion.h1 variants={reveal}>Paradise has a price.</motion.h1>
            <motion.p variants={reveal}>
              An original open-world crime saga set where the sun burns bright and every promise casts a shadow.
            </motion.p>
            <motion.div className="hero__actions" variants={reveal}>
              <button className="button button--hot" onClick={() => setTrailerOpen(true)}>
                <Play size={17} fill="currentColor" /> Play trailer
              </button>
              <a className="button button--line" href="#signup">
                Join the list <ArrowRight size={18} />
              </a>
            </motion.div>

            <motion.ul className="release-meta" variants={reveal}>
              <li>
                <span className="status-dot" aria-hidden="true" />
                {release.status}
              </li>
              <li>{release.window}</li>
              <li>{release.platform}</li>
            </motion.ul>
          </motion.div>

          <a className="hero__scroll" href="#story" aria-label="Scroll to the story">
            <span>Enter the city</span>
            <ArrowDown size={18} />
          </a>
        </section>

        <section className="story" id="story">
          <motion.div
            className="story__image-wrap"
            initial={{ clipPath: "inset(7% 7% 7% 7%)" }}
            whileInView={{ clipPath: "inset(0% 0% 0% 0%)" }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          >
            <img src="vice-haven-story.jpg" alt="Mara and Nico beside a sports car in Vice Haven" />
            <div className="story__shade" />
          </motion.div>

          <motion.div
            className="story__copy"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.4 }}
            transition={{ staggerChildren: 0.12 }}
          >
            <motion.span className="kicker" variants={reveal}>The story</motion.span>
            <motion.h2 variants={reveal}>Two lives.<br />One last shot.</motion.h2>
            <motion.p variants={reveal}>
              Mara Vale drives like she has nothing left to lose. Nico Reyes knows the city owes him. When a simple
              score goes sideways, they get one night to outrun Vice Haven's most powerful people.
            </motion.p>
          </motion.div>
        </section>

        <section className="world" id="world">
          <div className="world__intro section-pad">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.35 }}
              transition={{ staggerChildren: 0.1 }}
            >
              <motion.span className="kicker kicker--dark" variants={reveal}>One county. No safe side.</motion.span>
              <motion.h2 variants={reveal}>A world built<br />to break loose.</motion.h2>
            </motion.div>
            <motion.p
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.25, duration: 0.7 }}
            >
              Cross neon boulevards, mangrove channels, and storm-battered backroads. Every district has its own
              rhythm, factions, and way to make trouble.
            </motion.p>
          </div>

          <motion.figure
            className="world__visual"
            initial={{ opacity: 0.6, scale: 0.97 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 1 }}
          >
            <img src="vice-haven-world.jpg" alt="Aerial view of Vice Haven's city, coast, and wetlands" />
            <figcaption>Haven County, South Coast</figcaption>
          </motion.figure>

          <div className="districts section-pad">
            {districts.map((district, index) => (
              <motion.article
                key={district.name}
                className="district"
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
              >
                <span>{district.number}</span>
                <h3>{district.name}</h3>
                <p>{district.copy}</p>
              </motion.article>
            ))}
          </div>
        </section>

        <section className="features" id="features">
          <div className="features__sticky">
            <span className="kicker">Your city. Your rules.</span>
            <h2>Make<br />some noise.</h2>
          </div>
          <div className="feature-list">
            <motion.article
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.5 }}
            >
              <span>01</span>
              <h3>Drive everything</h3>
              <p>Muscle cars, superbikes, airboats, and aircraft tuned for speed and spectacular escapes.</p>
            </motion.article>
            <motion.article
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.5 }}
            >
              <span>02</span>
              <h3>Own the night</h3>
              <p>Build connections across a living criminal underworld where loyalty changes with the hour.</p>
            </motion.article>
            <motion.article
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.5 }}
            >
              <span>03</span>
              <h3>Choose the score</h3>
              <p>Plan your approach, pick your crew, and live with every consequence when the heat arrives.</p>
            </motion.article>
          </div>
        </section>

        <section className="demo" id="demo">
          <motion.div
            className="demo__inner"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8 }}
          >
            <span className="kicker">Playable prototype</span>
            <h2>Drive it before you buy it.</h2>
            <p>
              A first slice of the Vice Haven world is playable right now. Slip into the night, grab the cash,
              and outrun the heat in <strong>Night Shift</strong>.
            </p>
            <button className="button button--hot button--big" onClick={() => setGameOpen(true)}>
              <Gamepad2 size={19} /> Play the demo
            </button>
            <small>Runs in your browser — no download. Works with keyboard or touch.</small>
          </motion.div>
        </section>

        <section className="signup" id="signup">
          <div className="signup__glow" />
          <motion.div
            className="signup__content"
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.45 }}
            transition={{ duration: 0.8 }}
          >
            <Wordmark />
            <h2>Be first across the line.</h2>
            <p>Get new trailers, world reveals, and development updates from Haven County.</p>
            {signedUp ? (
              <motion.div className="signup__success" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                You're on the list. Welcome to Vice Haven.
              </motion.div>
            ) : (
              <form onSubmit={handleSignup}>
                <label className="sr-only" htmlFor="email">Email address</label>
                <input id="email" name="email" type="email" placeholder="EMAIL ADDRESS" required />
                <button type="submit" disabled={sending}>
                  {sending ? "Sending…" : (
                    <>
                      Notify me <ArrowRight size={18} />
                    </>
                  )}
                </button>
              </form>
            )}
            {formError && (
              <p className="signup__error" role="alert">
                Something went wrong — please try again, or email us directly.
              </p>
            )}
            <small>By signing up, you agree to receive Vice Haven news. Unsubscribe anytime.</small>
          </motion.div>
        </section>
      </main>

      <footer>
        <a href="#top"><Wordmark compact /></a>
        <p>
          {release.studio} — Vice Haven is an original fictional game concept. All names and characters are fictitious.
        </p>
        <div>
          <a href="#story">Story</a>
          <a href="#world">World</a>
          <button onClick={() => setTrailerOpen(true)}>Trailer</button>
          <a href={release.youtube} target="_blank" rel="noreferrer">YouTube</a>
        </div>
      </footer>

      <AnimatePresence>
        {trailerOpen && (
          <motion.div
            className="trailer-modal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            role="dialog"
            aria-modal="true"
            aria-label="Vice Haven trailer"
            onMouseDown={(event) => {
              if (event.target === event.currentTarget) setTrailerOpen(false);
            }}
          >
            <motion.div
              className="trailer-modal__content"
              initial={{ scale: 0.94, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.96, y: 10 }}
              transition={{ duration: 0.35 }}
            >
              <button className="trailer-modal__close" onClick={() => setTrailerOpen(false)} aria-label="Close trailer">
                <X size={25} />
              </button>
              <iframe
                src={trailerEmbedUrl}
                title="Vice Haven trailer"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              />
              <div className="trailer-modal__meta">
                <div>
                  <span>Official trailer</span>
                  <h2>Welcome to Vice Haven</h2>
                </div>
                <a href={`https://youtu.be/${trailerVideoId}`} target="_blank" rel="noreferrer">
                  <Volume2 size={21} />
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {gameOpen && (
          <motion.div
            className="game-modal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="game-modal__content"
              initial={{ scale: 0.96, y: 16 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.97, y: 8 }}
              transition={{ duration: 0.3 }}
            >
              <Game onClose={() => setGameOpen(false)} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;