// ─────────────────────────────────────────────────────────────
//  VICE HAVEN — NIGHT SHIFT (playable top-down driving prototype)
//  A canvas game engine: arcade car physics, neon city, police
//  heat, cash contracts. Written original & self-contained.
// ─────────────────────────────────────────────────────────────

export type GamePhase = "menu" | "playing" | "over";

export interface HudState {
  speed: number;
  carried: number;
  target: number;
  banks: number;
  health: number;
  heat: number;
  wanted: number;
}

export interface GameCallbacks {
  onPhase: (phase: GamePhase) => void;
  onHud: (hud: HudState) => void;
}

export type ControlName = "up" | "down" | "left" | "right";

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface Car {
  x: number;
  y: number;
  angle: number;
  speed: number;
}

interface Pickup {
  x: number;
  y: number;
  taken: boolean;
}

interface Police extends Car {
  active: boolean;
  health: number;
}

interface DropZone {
  x: number;
  y: number;
}

// World layout
const GRID = 8;
const BLOCK = 360;
const ROAD = 190;
const PITCH = BLOCK + ROAD;
const WORLD = GRID * PITCH + ROAD;
const HALF = WORLD / 2;

const PLAYER_R = 19;
const PLAYER_MAX = 520;
const PLAYER_ACCEL = 620;

// Deterministic-ish RNG (seeded)
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function clamp(v: number, lo: number, hi: number) {
  return v < lo ? lo : v > hi ? hi : v;
}

function angNorm(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function hitBlock(x: number, y: number, r: number, blocks: Rect[]): Rect | null {
  for (const b of blocks) {
    const cx = clamp(x, b.x, b.x + b.w);
    const cy = clamp(y, b.y, b.y + b.h);
    const dx = x - cx;
    const dy = y - cy;
    if (dx * dx + dy * dy < r * r) return b;
  }
  return null;
}

export class GameEngine {
  private ctx: CanvasRenderingContext2D;
  private canvas: HTMLCanvasElement;
  private cb: GameCallbacks;
  private raf = 0;
  private last = 0;
  private destroyed = false;

  private phase: GamePhase = "menu";
  private controls: Record<ControlName, boolean> = {
    up: false,
    down: false,
    left: false,
    right: false,
  };

  // static world
  private blocks: Rect[] = [];
  private roofs: { cx: number; cy: number; w: number; h: number; c: string }[] = [];
  private trees: { x: number; y: number; r: number }[] = [];

  // entities
  private player: Car = { x: 0, y: 0, angle: -Math.PI / 2, speed: 0 };
  private pickups: Pickup[] = [];
  private police: Police[] = [];
  private drop: DropZone | null = null;
  private fx: { x: number; y: number; t: number; max: number; c: string }[] = [];

  // state
  private carried = 0;
  private target = 150;
  private banks = 0;
  private health = 100;
  private heat = 0;
  private time = 0;
  private pickupTimer = 0;

  private camX = 0;
  private camY = 0;
  private zoom = 1;
  private w = 0;
  private h = 0;

  constructor(canvas: HTMLCanvasElement, cb: GameCallbacks) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas not supported");
    this.ctx = ctx;
    this.cb = cb;

    this.generateWorld();
    this.reset();
  }

  private generateWorld() {
    const rand = rng(1337);
    const palette = [
      "#241b2b",
      "#1b2230",
      "#2a1c2a",
      "#1c2a2a",
      "#2c2030",
      "#182030",
      "#2e1e28",
    ];
    for (let i = 0; i < GRID; i++) {
      for (let j = 0; j < GRID; j++) {
        const x = i * PITCH + ROAD;
        const y = j * PITCH + ROAD;
        this.blocks.push({ x, y, w: BLOCK, h: BLOCK });
        // decorative roof tiles
        const cols = 2;
        for (let a = 0; a <= cols; a++) {
          for (let b = 0; b <= cols; b++) {
            if (rand() < 0.35) continue;
            const tw = BLOCK / (cols + 1) - 34;
            const th = BLOCK / (cols + 1) - 34;
            const tx = x + 18 + a * (BLOCK / (cols + 1));
            const ty = y + 18 + b * (BLOCK / (cols + 1));
            this.roofs.push({
              cx: tx,
              cy: ty,
              w: tw,
              h: th,
              c: palette[Math.floor(rand() * palette.length)],
            });
          }
        }
      }
    }
    // palm trees along some road edges
    for (let i = 0; i < 90; i++) {
      const gi = Math.floor(rand() * GRID);
      const gj = Math.floor(rand() * GRID);
      const bx = gi * PITCH;
      const by = gj * PITCH;
      const edge = Math.floor(rand() * 4);
      let x = bx + ROAD * (0.2 + rand() * 0.6);
      let y = by + ROAD * (0.2 + rand() * 0.6);
      if (edge === 0) y = by + ROAD * 0.5;
      else if (edge === 1) y = by + ROAD * 0.5;
      else if (edge === 2) y = by + PITCH - ROAD * 0.5;
      if (edge < 2) x = bx + ROAD * 0.5 + rand() * (PITCH - ROAD);
      else x = bx + ROAD * 0.5 + rand() * (PITCH - ROAD);
      if (edge === 2 || edge === 3) x = bx + ROAD * 0.5 + rand() * (PITCH - ROAD);
      else y = by + ROAD * 0.5 + rand() * (ROAD * 0.1);
      this.trees.push({ x: clamp(x, 40, WORLD - 40), y: clamp(y, 40, WORLD - 40), r: 9 + rand() * 8 });
    }
  }

  private spawnPickup() {
    const rand = rng(Math.floor(Math.random() * 1e9));
    const gi = Math.floor(rand() * (GRID + 1));
    const gj = Math.floor(rand() * (GRID + 1));
    const x = clamp(gi * PITCH + rand() * PITCH, ROAD * 0.5, WORLD - ROAD * 0.5);
    const y = clamp(gj * PITCH + rand() * PITCH, ROAD * 0.5, WORLD - ROAD * 0.5);
    this.pickups.push({ x, y, taken: false });
  }

  reset() {
    this.player = { x: HALF, y: HALF, angle: -Math.PI / 2, speed: 0 };
    this.pickups = [];
    this.police = [];
    this.drop = null;
    this.carried = 0;
    this.target = 150;
    this.banks = 0;
    this.health = 100;
    this.heat = 0;
    this.time = 0;
    this.pickupTimer = 0;
    this.camX = this.player.x;
    this.camY = this.player.y;
    for (let i = 0; i < 4; i++) this.spawnPickup();
  }

  start() {
    this.reset();
    this.setPhase("playing");
  }

  private setPhase(p: GamePhase) {
    this.phase = p;
    this.cb.onPhase(p);
    this.pushHud();
  }

  private pushHud() {
    this.cb.onHud({
      speed: Math.abs(this.player.speed),
      carried: Math.floor(this.carried),
      target: this.target,
      banks: this.banks,
      health: Math.round(this.health),
      heat: Math.round(this.heat),
      wanted: Math.min(5, Math.floor(this.heat / 22)),
    });
  }

  setControl(name: ControlName, on: boolean) {
    this.controls[name] = on;
  }

  resize(w: number, h: number) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.floor(w * dpr);
    this.canvas.height = Math.floor(h * dpr);
    this.canvas.style.width = w + "px";
    this.canvas.style.height = h + "px";
    this.w = w;
    this.h = h;
    this.zoom = clamp(Math.min(w, h) / 780, 0.8, 1.45);
  }

  run() {
    const loop = (t: number) => {
      if (this.destroyed) return;
      const dt = Math.min(0.033, (t - this.last) / 1000 || 0.016);
      this.last = t;
      if (this.phase === "playing") this.update(dt);
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
  }

  // ── simulation ────────────────────────────────────────────
  private update(dt: number) {
    this.time += dt;

    // die check
    if (this.health <= 0) {
      this.setPhase("over");
      return;
    }

    this.updatePlayer(dt);

    // pickups
    for (const p of this.pickups) {
      if (p.taken) continue;
      const d = Math.hypot(p.x - this.player.x, p.y - this.player.y);
      if (d < PLAYER_R + 22) {
        p.taken = true;
        const val = 15 + Math.floor(Math.random() * 30);
        this.carried += val;
        this.heat = Math.min(130, this.heat + 6);
        this.fx.push({ x: p.x, y: p.y, t: 0, max: 0.5, c: "#63e6dd" });
        if (this.carried >= this.target) this.spawnDrop();
      }
    }
    this.pickups = this.pickups.filter((p) => !p.taken);
    if (this.pickups.length < 3) {
      this.pickupTimer += dt;
      if (this.pickupTimer > 1.4) {
        this.pickupTimer = 0;
        this.spawnPickup();
      }
    }

    // drop-off
    if (this.drop) {
      const dropX = this.drop.x;
      const dropY = this.drop.y;
      const d = Math.hypot(dropX - this.player.x, dropY - this.player.y);
      if (d < PLAYER_R + 34) {
        this.banks += 1;
        this.carried = 0;
        this.target = 150 + this.banks * 160;
        this.heat = Math.max(0, this.heat - 45);
        this.health = Math.min(100, this.health + 20);
        this.drop = null;
        this.fx.push({ x: dropX, y: dropY, t: 0, max: 0.7, c: "#ff4e78" });
        for (let i = 0; i < 3; i++) this.spawnPickup();
      }
    }

    // heat decay when chill
    if (this.time % 26 < 1 && this.player.speed < 60 && this.heat > 0) {
      this.heat = Math.max(0, this.heat - 2);
    }

    // police management
    const wantedCount = Math.min(6, this.heat > 4 ? 2 : this.heat > 0 ? 1 : 0);
    while (this.police.length < wantedCount) this.police.push(this.newPolice());
    while (this.police.length > wantedCount) this.police.pop();
    for (const cop of this.police) this.updatePolice(cop, dt);

    // fx
    for (const f of this.fx) f.t += dt;
    this.fx = this.fx.filter((f) => f.t < f.max);

    this.pushHud();
  }

  private updatePlayer(dt: number) {
    const c = this.controls;
    const p = this.player;

    let throttle = 0;
    if (c.up) throttle = 1;
    else if (c.down) throttle = -1;

    const steer = (c.left ? 1 : 0) - (c.right ? 1 : 0);

    // acceleration / friction
    if (throttle !== 0) {
      p.speed += throttle * PLAYER_ACCEL * dt;
    } else {
      p.speed *= Math.pow(0.25, dt);
    }
    p.speed = clamp(p.speed, -PLAYER_MAX * 0.5, PLAYER_MAX);

    // steering scales with speed
    const speedFactor = clamp(Math.abs(p.speed) / PLAYER_MAX, 0, 1);
    const turn = steer * 2.6 * (0.35 + speedFactor) * (p.speed >= 0 ? 1 : -1);
    p.angle += turn * dt;

    // integrate
    p.x += Math.cos(p.angle) * p.speed * dt;
    p.y += Math.sin(p.angle) * p.speed * dt;

    // world bounds
    p.x = clamp(p.x, 30, WORLD - 30);
    p.y = clamp(p.y, 30, WORLD - 30);

    // block collisions
    const hit = hitBlock(p.x, p.y, PLAYER_R, this.blocks);
    if (hit) {
      // push out
      const cx = clamp(p.x, hit.x, hit.x + hit.w);
      const cy = clamp(p.y, hit.y, hit.y + hit.h);
      const dx = p.x - cx;
      const dy = p.y - cy;
      const len = Math.hypot(dx, dy) || 1;
      p.x = cx + (dx / len) * (PLAYER_R + 2);
      p.y = cy + (dy / len) * (PLAYER_R + 2);
      if (Math.abs(p.speed) > 140) {
        this.heat = Math.min(130, this.heat + 7);
        this.health = Math.max(0, this.health - 3);
        this.fx.push({ x: p.x, y: p.y, t: 0, max: 0.4, c: "#ffb454" });
      }
      p.speed *= 0.4;
    }

    // camera follow
    this.camX = p.x;
    this.camY = p.y;
  }

  private newPolice(): Police {
    const edge = Math.floor(Math.random() * 4);
    let x = HALF;
    let y = HALF;
    if (edge === 0) { x = 80; y = Math.random() * WORLD; }
    if (edge === 1) { x = WORLD - 80; y = Math.random() * WORLD; }
    if (edge === 2) { y = 80; x = Math.random() * WORLD; }
    if (edge === 3) { y = WORLD - 80; x = Math.random() * WORLD; }
    return { x, y, angle: 0, speed: 0, active: true, health: 100 };
  }

  private updatePolice(cop: Police, dt: number) {
    const p = this.player;
    const desired = Math.atan2(p.y - cop.y, p.x - cop.x);
    let diff = angNorm(desired - cop.angle);
    cop.angle += clamp(diff, -3.2 * dt, 3.2 * dt);
    cop.speed += 620 * dt;
    cop.speed = clamp(cop.speed, 0, 500);
    cop.x += Math.cos(cop.angle) * cop.speed * dt;
    cop.y += Math.sin(cop.angle) * cop.speed * dt;

    const hit = hitBlock(cop.x, cop.y, 18, this.blocks);
    if (hit) {
      const cx = clamp(cop.x, hit.x, hit.x + hit.w);
      const cy = clamp(cop.y, hit.y, hit.y + hit.h);
      const dx = cop.x - cx;
      const dy = cop.y - cy;
      const len = Math.hypot(dx, dy) || 1;
      cop.x = cx + (dx / len) * 20;
      cop.y = cy + (dy / len) * 20;
      cop.speed *= 0.5;
    }

    // ram the player
    const d = Math.hypot(p.x - cop.x, p.y - cop.y);
    if (d < PLAYER_R + 20 && cop.speed > 110) {
      this.health = Math.max(0, this.health - 8);
      this.heat = Math.min(130, this.heat + 10);
      // knock player
      const a = Math.atan2(p.y - cop.y, p.x - cop.x);
      p.speed = 260;
      p.angle = a;
      cop.speed = 140;
      this.fx.push({ x: p.x, y: p.y, t: 0, max: 0.5, c: "#ff4e78" });
    }
  }

  private spawnDrop() {
    const gi = Math.floor(Math.random() * (GRID + 1));
    const gj = Math.floor(Math.random() * (GRID + 1));
    this.drop = {
      x: clamp(gi * PITCH + Math.random() * PITCH, ROAD * 0.5, WORLD - ROAD * 0.5),
      y: clamp(gj * PITCH + Math.random() * PITCH, ROAD * 0.5, WORLD - ROAD * 0.5),
    };
  }

  // ── rendering ─────────────────────────────────────────────
  private render() {
    const ctx = this.ctx;
    const { w, h, zoom } = this;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(this.canvas.width / w, this.canvas.height / h);

    // background asphalt
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "#100b14");
    g.addColorStop(1, "#0b0910");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.scale(zoom, zoom);
    ctx.translate(-this.camX, -this.camY);

    const viewL = this.camX - w / zoom / 2 - 60;
    const viewR = this.camX + w / zoom / 2 + 60;
    const viewT = this.camY - h / zoom / 2 - 60;
    const viewB = this.camY + h / zoom / 2 + 60;

    // road grid lines
    ctx.strokeStyle = "rgba(255,255,255,0.05)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i <= GRID; i++) {
      const lp = i * PITCH;
      ctx.moveTo(lp, viewT);
      ctx.lineTo(lp, viewB);
      ctx.moveTo(viewL, lp);
      ctx.lineTo(viewR, lp);
    }
    ctx.stroke();

    // lane dashes
    ctx.strokeStyle = "rgba(255,225,140,0.28)";
    ctx.lineWidth = 3;
    ctx.setLineDash([26, 26]);
    ctx.beginPath();
    for (let i = 0; i <= GRID; i++) {
      const lp = i * PITCH + ROAD / 2;
      ctx.moveTo(lp, viewT);
      ctx.lineTo(lp, viewB);
      ctx.moveTo(viewL, lp);
      ctx.lineTo(viewR, lp);
    }
    ctx.stroke();
    ctx.setLineDash([]);

    // blocks with neon edge
    for (const b of this.blocks) {
      if (b.x > viewR || b.x + b.w < viewL || b.y > viewB || b.y + b.h < viewT) continue;
      ctx.fillStyle = "#0c0a11";
      ctx.fillRect(b.x, b.y, b.w, b.h);
      ctx.strokeStyle = "rgba(99,230,221,0.16)";
      ctx.lineWidth = 3;
      ctx.strokeRect(b.x + 1.5, b.y + 1.5, b.w - 3, b.h - 3);
    }

    // roofs
    for (const r of this.roofs) {
      if (r.cx > viewR || r.cx + r.w < viewL || r.cy > viewB || r.cy + r.h < viewT) continue;
      ctx.fillStyle = r.c;
      ctx.fillRect(r.cx, r.cy, r.w, r.h);
      ctx.fillStyle = "rgba(255,255,255,0.05)";
      ctx.fillRect(r.cx, r.cy + r.h - 8, r.w, 8);
    }

    // palm trees
    for (const t of this.trees) {
      if (t.x > viewR || t.x < viewL || t.y > viewB || t.y < viewT) continue;
      ctx.fillStyle = "#123a2e";
      ctx.beginPath();
      ctx.arc(t.x, t.y, t.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#2fbf8f";
      ctx.beginPath();
      ctx.arc(t.x, t.y, t.r * 0.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // pickups
    for (const p of this.pickups) {
      if (p.x > viewR || p.x < viewL || p.y > viewB || p.y < viewT) continue;
      ctx.fillStyle = "#63e6dd";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#0c0a11";
      ctx.font = "bold 13px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("$", p.x, p.y + 1);
    }

    // drop zone
    if (this.drop) {
      const pulse = 0.5 + 0.5 * Math.sin(this.time * 5);
      ctx.strokeStyle = `rgba(255,78,120,${0.4 + pulse * 0.4})`;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(this.drop.x, this.drop.y, 34 + pulse * 8, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = "#ff4e78";
      ctx.font = "bold 18px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("DROP", this.drop.x, this.drop.y);
    }

    // police
    for (const cop of this.police) {
      this.drawCar(cop.x, cop.y, cop.angle, "#2f6dff", "#bcd2ff");
    }

    // player
    this.drawCar(this.player.x, this.player.y, this.player.angle, "#ff4e78", "#ffd9e2");

    // fx
    for (const f of this.fx) {
      const alpha = 1 - f.t / f.max;
      ctx.strokeStyle = f.c;
      ctx.globalAlpha = alpha;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(f.x, f.y, 8 + f.t * 120, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    ctx.restore();

    // vignette
    const vg = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.75);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.55)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, w, h);

    this.drawMinimap(ctx);
    ctx.restore();
  }

  private drawCar(x: number, y: number, angle: number, body: string, accent: string) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.beginPath();
    ctx.ellipse(2, 4, 24, 15, 0, 0, Math.PI * 2);
    ctx.fill();
    // body (rounded rect pointing +x)
    this.roundRect(ctx, -24, -14, 48, 28, 7);
    ctx.fillStyle = body;
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.6)";
    ctx.lineWidth = 2;
    ctx.stroke();
    // windshield
    this.roundRect(ctx, -2, -10, 10, 20, 4);
    ctx.fillStyle = accent;
    ctx.fill();
    // headlights
    ctx.fillStyle = "#fff3c4";
    ctx.fillRect(20, -11, 4, 7);
    ctx.fillRect(20, 4, 4, 7);
    // tail lights
    ctx.fillStyle = "#ff2b4e";
    ctx.fillRect(-24, -11, 3, 7);
    ctx.fillRect(-24, 4, 3, 7);
    ctx.restore();
  }

  private roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  private drawMinimap(ctx: CanvasRenderingContext2D) {
    const { w } = this;
    const size = 112;
    const pad = 14;
    const ox = w - size - pad;
    const oy = pad;
    const scale = size / WORLD;
    ctx.save();
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = "rgba(8,6,10,0.8)";
    this.roundRect(ctx, ox - 5, oy - 5, size + 10, size + 10, 10);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,78,120,0.4)";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // blocks
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    for (const b of this.blocks) {
      ctx.fillRect(ox + b.x * scale, oy + b.y * scale, b.w * scale, b.h * scale);
    }
    // drop
    if (this.drop) {
      ctx.fillStyle = "#ff4e78";
      ctx.beginPath();
      ctx.arc(ox + this.drop.x * scale, oy + this.drop.y * scale, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    // police
    ctx.fillStyle = "#2f6dff";
    for (const cop of this.police) {
      ctx.beginPath();
      ctx.arc(ox + cop.x * scale, oy + cop.y * scale, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
    // player
    ctx.fillStyle = "#ff4e78";
    ctx.beginPath();
    ctx.arc(ox + this.player.x * scale, oy + this.player.y * scale, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}
