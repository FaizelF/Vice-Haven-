import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, ArrowUp, MoveDown, Play, RotateCcw, X } from "lucide-react";
import { GameEngine, GamePhase, HudState, ControlName } from "./engine";

interface GameProps {
  onClose: () => void;
}

const emptyHud: HudState = {
  speed: 0,
  carried: 0,
  target: 150,
  banks: 0,
  health: 100,
  heat: 0,
  wanted: 0,
};

export default function Game({ onClose }: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [phase, setPhase] = useState<GamePhase>("menu");
  const [hud, setHud] = useState<HudState>(emptyHud);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const engine = new GameEngine(canvas, {
      onPhase: (p) => setPhase(p),
      onHud: (h) => setHud(h),
    });
    engineRef.current = engine;

    const doResize = () => {
      const rect = wrap.getBoundingClientRect();
      engine.resize(rect.width, rect.height);
    };
    doResize();
    const observer = new ResizeObserver(doResize);
    observer.observe(wrap);
    engine.run();

    return () => {
      observer.disconnect();
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  const press = (name: ControlName, on: boolean) => () => engineRef.current?.setControl(name, on);

  const desiredWanted = Math.min(5, Math.floor(hud.heat / 22));

  return (
    <div className="game-root">
      <div ref={wrapRef} className="game-stage">
        <canvas ref={canvasRef} />

        {/* top-left HUD */}
        <div className="game-hud game-hud--tl">
          <div className="hud-row">
            <span className="hud-label">CASH</span>
            <span className="hud-cash">${hud.carried.toLocaleString()}</span>
            <span className="hud-goal">/{hud.target.toLocaleString()}</span>
          </div>
          <div className="hud-wanted" aria-label={`Wanted level ${desiredWanted} of 5`}>
            {[1, 2, 3, 4, 5].map((s) => (
              <span key={s} className={s <= desiredWanted ? "star on" : "star"} />
            ))}
          </div>
          <div className="hud-line">
            <span className="hud-label">BANKS</span>
            <span className="hud-value">{hud.banks}</span>
          </div>
        </div>

        {/* top-right speed + health */}
        <div className="game-hud game-hud--tr">
          <div className="speed-num">{Math.round(hud.speed / 5)}</div>
          <div className="speed-unit">KM/H</div>
          <div className="health-bar">
            <div className="health-fill" style={{ width: `${hud.health}%` }} />
          </div>
        </div>

        {/* objective banner */}
        <div className="game-objective">
          {hud.carried >= hud.target
            ? "DROP-OFF ACTIVATED — reach the red zone"
            : "Grab cash bags '$', then hit the DROP zone"}
        </div>

        {/* close */}
        <button className="game-close" onClick={onClose} aria-label="Exit game">
          <X size={22} />
        </button>

        {/* touch controls */}
        <div className="game-touch">
          <div className="touch-pad touch-pad--steer">
            <button onPointerDown={press("left", true)} onPointerUp={press("left", false)} onPointerLeave={press("left", false)} onPointerCancel={press("left", false)} aria-label="Steer left">
              <ArrowLeft size={24} />
            </button>
            <button onPointerDown={press("right", true)} onPointerUp={press("right", false)} onPointerLeave={press("right", false)} onPointerCancel={press("right", false)} aria-label="Steer right">
              <ArrowRight size={24} />
            </button>
          </div>
          <div className="touch-pad touch-pad--throttle">
            <button onPointerDown={press("up", true)} onPointerUp={press("up", false)} onPointerLeave={press("up", false)} onPointerCancel={press("up", false)} aria-label="Accelerate">
              <ArrowUp size={24} />
            </button>
            <button onPointerDown={press("down", true)} onPointerUp={press("down", false)} onPointerLeave={press("down", false)} onPointerCancel={press("down", false)} aria-label="Brake / reverse">
              <MoveDown size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* menu overlay */}
      {phase === "menu" && (
        <div className="game-overlay">
          <span className="game-eyebrow">VICE HAVEN · PLAYABLE DEMO</span>
          <h1>Night Shift</h1>
          <p>
            Drive the neon grid. Grab the cash. Shake the heat. Reach the drop zone and bank your score.
          </p>
          <div className="game-controls">
            <span><kbd>W</kbd> / <kbd>↑</kbd> Accelerate</span>
            <span><kbd>S</kbd> / <kbd>↓</kbd> Brake</span>
            <span><kbd>A</kbd> <kbd>D</kbd> Steer</span>
          </div>
          <button className="game-start" onClick={() => engineRef.current?.start()}>
            <Play size={18} fill="currentColor" /> Start shift
          </button>
        </div>
      )}

      {/* game over overlay */}
      {phase === "over" && (
        <div className="game-overlay">
          <span className="game-eyebrow">BUSTED</span>
          <h1>You went down swinging.</h1>
          <p>
            You banked <strong>${(hud.banks * 300).toLocaleString()}</strong> across{" "}
            <strong>{hud.banks}</strong> contract{hud.banks === 1 ? "" : "s"} before the heat caught up.
          </p>
          <button className="game-start" onClick={() => engineRef.current?.start()}>
            <RotateCcw size={18} /> Run it back
          </button>
        </div>
      )}
    </div>
  );
}
